Component({
  properties: {
    text: {
      type: String,
      value: "正在加载..."
    }
  }
})
