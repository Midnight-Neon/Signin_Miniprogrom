import tui from '../../common/httpRequest'
Page({
  data: {
    webURL: '/static/images/signin/',
    height: 20,
    top: 12,
    statusBarHeight: 12,
    winWidth: 600,
    current: 0,
    x1: 0,
    x2: 0,
    theme: 'day', //主题：day|night 白天|夜晚
    calendarH: 380,
    rankingH: 420,
    userList: [{
        name: '一谦年以后',
        imgUrl: 'mine_avatar_3x.jpg',
        days: 1278
      },
      {
        name: '石头花',
        imgUrl: '1.jpg',
        days: 1200
      },
      {
        name: '贝贝',
        imgUrl: 'mine_avatar_3x.jpg',
        days: 1100
      },
      {
        name: '诸事顺',
        imgUrl: '2.jpg',
        days: 1000
      },
      {
        name: '鱼儿',
        imgUrl: 'mine_avatar_3x.jpg',
        days: 986
      },
      {
        name: '罗小仙',
        imgUrl: 'mine_avatar_3x.jpg',
        days: 984
      },
      {
        name: '钟小悠',
        imgUrl: '2.jpg',
        days: 800
      },
      {
        name: '柳林风声',
        imgUrl: 'mine_avatar_3x.jpg',
        days: 769
      },
      {
        name: 'echo.',
        imgUrl: '2.jpg',
        days: 666
      },
      {
        name: '漂流瓶',
        imgUrl: 'mine_avatar_3x.jpg',
        days: 620
      }
    ],
    year: 2020,
    month: 7,
    day: 7,
    showTitle: '2020年07月',
    //日历数据
    calendarList: [],
    signed: false,
    swiperIndex: 1,
    loading: false
  },

  onLoad: function () {
    const date = new Date();
    const hours = date.getHours();
    if (hours >= 18 || hours < 6) {
      this.setData({
        theme:'night'
      })
    }
    //初始化日历数据  近3个月 (数据可后端传回)
    let year=date.getFullYear();
    let month=date.getMonth() + 1;
    this.setData({
      year:year,
      month:month,
      day:date.getDate(),
      showTitle:`${year}年${this.formatNum(month)}月`,
      calendarList:[{}, this.getCalendarData(year, month, 1), {}]
    })

    setTimeout(() => {
      let sys = wx.getSystemInfoSync();
      let winWidth = sys.windowWidth;
      const w = this.upx2px(32) / 2;

      this.setData({
        winWidth:winWidth,
        x1:winWidth / 4 - w,
        x2:(winWidth * 3) / 4 - w,
        calendarH:sys.windowHeight - this.upx2px(440 + 100 + 64),
        rankingH:sys.windowHeight - this.upx2px(440)
      })
    }, 66);
  },
  upx2px(num){
    return num / 750 * wx.getSystemInfoSync().windowWidth
  },
  initNavigation(e) {
    this.setData({
      height:e.detail.height,
      top:e.detail.top,
      statusBarHeight:e.detail.statusBarHeight
    })
  },
  back() {
    let pages = getCurrentPages();
    if (pages.length > 1) {
      wx.navigateBack();
    } else {
      wx.switchTab({
        url: '/pages/tabbar/index/index'
      });
    }
  },
  switchTab(e) {
    let index=Number(e.currentTarget.dataset.index)
    this.setData({
      current:index
    })
  },
  //此处只为做演示，实际开发应按照时间切换
  themeChange() {
    this.setData({
      theme:this.data.theme === 'day' ? 'night' : 'day'
    })
  },
  formatNum: function(num) {
    return num < 10 ? '0' + num : num + '';
  },
  //一个月有多少天
  getMonthDay(year, month) {
    let days = new Date(year, month, 0).getDate();
    return days;
  },
  getWeekday(year, month) {
    let date = new Date(`${year}/${month}/01 00:00:00`);
    return date.getDay();
  },
  change: function(e) {
    let current = e.detail.current;
    let year = this.data.year;
    let month = this.data.month;
    this.setData({
      swiperIndex:current
    })
    setTimeout(() => {
      if (current == 0) {
        month = month - 1;
        year = month < 1 ? year - 1 : year;
        month = month < 1 ? 12 : month;
        if (!this.data.calendarList[0].data) {
          // this.loading=true;
          let val=`calendarList[0]`
          this.setData({
            [val]:this.getCalendarData(year, month, 0)
          })
        }
      } else if (current == 2) {
        month = month + 1;
        year = month > 12 ? year + 1 : year;
        month = month > 12 ? 1 : month;
        if (!this.data.calendarList[2].data) {
          // this.loading=true;
          let val=`calendarList[2]`
          this.setData({
            [val]:this.getCalendarData(year, month, 2)
          })
        }
      }
      this.setData({
        showTitle:`${year}年${this.formatNum(month)}月`
      })
      // this.loading=false;
    }, 300)
  },
  getCalendarData(year, month, index) {
    let days = this.getMonthDay(year, month);
    //前补位
    let frontItemNum = this.getWeekday(year, month);
    //后补位
    let behindItemNum = 42 - days - frontItemNum;
    let data = [];
    for (let f = 0; f < frontItemNum; f++) {
      data.push({});
    }

    for (let i = 0; i < days; i++) {
      //根据实际情况调整即可
      //连续签到天数
      let signInDays = 0;
      //gift:0-无奖励，1-礼品 2-积分翻倍
      let gift = 0;
      if (index !== 0) {
        i === 6 && (gift = 1);
        i === 20 && (gift = 2);
      }
      //是否已签到
      let signed = false;

      if (i === this.data.day - 3 && this.data.month == month) {
        signed = true;
      }

      data.push({
        date: i + 1,
        signInDays: signInDays,
        gift: gift,
        signed: signed
      });
    }
    for (let b = 0; b < behindItemNum; b++) {
      data.push({});
    }

    return {
      year: year,
      month: month,
      frontItemNum: frontItemNum,
      behindItemNum: behindItemNum,
      data: data
    };
  },
  monthChange(e) {
    let index=Number(e.currentTarget.dataset.index)
    if (index == 0) {
      this.setData({
        swiperIndex:this.data.swiperIndex - 1
      })
    } else {
      this.setData({
        swiperIndex:this.data.swiperIndex + 1
      })
    }
  },
  detail(e) {
    let dataset=e.currentTarget.dataset;
    let gift=dataset.gift || 0;
    let missedSign=dataset.missedsign;
    if (gift == 1) {
      tui.modal('礼品', '每连续签到7天即可完成连签任务', false, (res) => {}, "#fa523e")
    } else if (gift == 2) {
      tui.modal('积分双倍', '每连续签到21天即可领取双倍积分奖励', false, (res) => {}, "#fa523e")
    }
    if (missedSign) {
      tui.modal('补签', '您本月的补签机会已用完', false, (res) => {}, "#fa523e")
    }

  },
  btnSign() {
    tui.toast('签到成功');
    let frontItemNum = this.getWeekday(this.data.year, this.data.month);
    let item = this.data.calendarList[1];
    let val=`calendarList[1].data[${this.data.day - 1 + frontItemNum}].signed`
    this.setData({
      [val]:true,
      signed:true
    })
  }
})
