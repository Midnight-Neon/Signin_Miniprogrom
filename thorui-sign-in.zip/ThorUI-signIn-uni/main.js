import Vue from 'vue'
import App from './App'
import tui from './common/httpRequest'
Vue.config.productionTip = false

Vue.prototype.tui = tui
Vue.prototype.$eventHub = Vue.prototype.$eventHub || new Vue()
App.mpType = 'app'

const app = new Vue({
	...App
})
app.$mount()